const { Client } = require('ssh2'); 
const conn = new Client(); 
conn.on('ready', () => { 
  const cmd = `cd /root/wr-music-app && docker compose exec -T db psql -U postgres -d wrmusic -c "ALTER TABLE settings DROP COLUMN duedaysforecast; ALTER TABLE settings ADD COLUMN \\"dueDaysForecast\\" text DEFAULT '5,10,15,20';"`;
  conn.exec(cmd, (err, stream) => { 
    if (err) throw err; 
    stream.on('data', data => process.stdout.write(data.toString())); 
    stream.stderr.on('data', data => process.stderr.write(data.toString())); 
    stream.on('close', () => conn.end()); 
  }); 
}).connect({ 
  host: '179.197.76.174', 
  port: 22, 
  username: 'root', 
  password: 'Walysson2003@', 
  readyTimeout: 30000 
});
