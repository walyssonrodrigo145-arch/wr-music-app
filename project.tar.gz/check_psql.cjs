const {Client} = require('ssh2');
const c = new Client();
c.on('ready', () => {
  c.exec('docker exec wr-music-app-db-1 psql -U postgres -d wrmusic -c "\\d daily_study_plans"', (err, stream) => {
    stream.on('data', d => console.log(d.toString()));
    stream.stderr.on('data', d => console.error(d.toString()));
    stream.on('close', () => c.end());
  });
}).connect({host:'179.197.76.174', port:22, username:'root', password:'Walysson2003@'});
